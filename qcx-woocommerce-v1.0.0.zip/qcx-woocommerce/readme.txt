=== QC Express for WooCommerce ===
Contributor: Eriyo Digital
Tags: shipping, logistics, woocommerce, qc express, nigeria
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrate QC Express shipping services with WooCommerce for seamless shipping rate calculation, booking creation, and tracking.

== Description ==

QC Express for WooCommerce provides seamless integration with QC Express shipping services, enabling automatic shipping rate calculation, booking creation, and package tracking directly from your WooCommerce store.

**Key Features:**

* **Real-time Shipping Rates** - Get live shipping quotes during checkout
* **Automatic Booking Creation** - Create shipments automatically when orders are processed
* **Insurance Options** - Let customers choose insurance coverage or make it mandatory
* **Document & Parcel Support** - Handle both document and parcel shipments
* **Custom Tracking Pages** - Provide detailed tracking information on your website
* **Admin Management** - Create and cancel bookings from the WordPress admin
* **Comprehensive Logging** - Detailed logs for debugging and monitoring
* **Multi-currency Support** - Works with different currencies
* **Shipping Zones** - Configure different settings per shipping zone

**Supported Features:**

* Domestic and international shipping
* Weight and dimension-based calculations
* Insurance coverage options
* Commodity code support for products (required for international shipments)
* Markup configuration (fixed amount or percentage)
* Document persistence and download

**International Shipping Requirements:**

For international shipments, each product must have a commodity code. Add a custom field named `commodity_code` to your products with the appropriate HS (Harmonized System) code. This is mandatory for customs clearance and accurate shipping calculations.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/qcx-woocommerce` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to WooCommerce → Settings → QC Express to configure your API credentials.
4. Add QC Express as a shipping method in your shipping zones.

== Configuration ==

1. **API Setup**: Enter your QC Express API credentials in WooCommerce → Settings → QC Express
2. **Business Details**: Configure your sender information and default package dimensions
3. **Shipping Zones**: Add "QC Express" as a shipping method in your desired shipping zones
4. **Insurance**: Configure how insurance options are presented to customers
5. **Markup**: Set any markup on shipping rates (optional)

== Frequently Asked Questions ==

= Do I need a QC Express business account? =

Yes, you need a QC Express business account and API credentials to use this plugin.

= Can I customize the shipping rates? =

Yes, you can add markup (fixed amount or percentage) to the rates returned by QC Express.

= Does this work with variable products? =

Yes, the plugin calculates shipping based on the total weight and dimensions of all items in the cart.

= Can customers track their shipments? =

Yes, the plugin provides custom tracking pages with detailed shipment information and event timeline.

= Is this plugin free? =

The plugin is free, but you'll need a QC Express account and may incur shipping charges based on your usage.

= How do I add commodity codes for international shipping? =

For international shipments, commodity codes are mandatory. Add a custom field named `commodity_code` to each product with the appropriate HS (Harmonized System) code. You can add custom fields in the product edit screen under the "Custom Fields" section, or use the "Additional Information" tab to add custom attributes.

== Screenshots ==

1. QC Express settings page
2. Shipping method configuration
3. Checkout with shipping options
4. Order admin with booking controls
5. Custom tracking page

== Changelog ==

= 1.0.0 =
* Initial release
* Real-time shipping rate calculation
* Automatic booking creation
* Custom tracking pages
* Insurance option support
* Admin booking management
* Comprehensive logging

== Upgrade Notice ==

= 1.0.0 =
Initial release of QC Express for WooCommerce.

== Support ==

For support, please contact tech@eriyodigital.com or customercare@quartzclassic.com.

== API Requirements ==

This plugin requires:
* QC Express business account
* Valid API credentials (Client ID and Bearer Token)
* WooCommerce 3.0 or higher
* PHP 7.4 or higher

== Privacy Policy ==

This plugin sends shipping information to QC Express servers for rate calculation and booking creation. Please review QC Express's privacy policy for information on how they handle data.
