<?php
/**
 * QC Express WooCommerce Plugin Uninstall
 * 
 * This file is executed when the plugin is uninstalled (deleted).
 * It removes all plugin options, settings, and cached data.
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete plugin options
delete_option('qcxwc_settings');
delete_option('qcx_tracking_rules_flushed');

// Delete any transients (cached data)
global $wpdb;

// Delete all QCX-related transients
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_qcx_%'");
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_qcx_%'");

// Delete all order meta data created by the plugin
$qcx_meta_keys = [
    '_qcx_booking_id',
    '_qcx_tracking_id',
    '_qcx_tracking_number',
    '_qcx_tracking_url',
    '_qcx_piece_tracking_numbers',
    '_qcx_label_attachment_ids',
    '_qcx_booking_cancelled',
    '_qcx_cancellation_reason',
    '_qcx_cancellation_date',
    '_qcx_booking_payload',
    '_qcx_booking_response',
    '_qcx_documents',
    '_qcx_insurance_selected',
    '_qcx_declared_value',
    '_qcx_commodity_code'
];

foreach ($qcx_meta_keys as $meta_key) {
    $wpdb->delete(
        $wpdb->postmeta,
        ['meta_key' => $meta_key],
        ['%s']
    );
}

// Delete shipping method instances
$wpdb->delete(
    $wpdb->options,
    ['option_name' => 'woocommerce_qcxwc_shipping_%'],
    ['%s']
);

// Clean up any QCX-related user meta
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'qcx_%'");

// Remove any custom database tables (if we had created any)
// Note: This plugin doesn't create custom tables, but this is where you'd drop them

// Clear any cached data
wp_cache_flush();

// Log the uninstall (optional - for debugging)
if (function_exists('wc_get_logger')) {
    wc_get_logger()->info('QC Express plugin uninstalled and data cleaned up', ['source' => 'qcxwc']);
}
