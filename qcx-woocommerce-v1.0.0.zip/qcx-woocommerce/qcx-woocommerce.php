<?php
/*
 * Plugin Name: QC Express for WooCommerce
 * Plugin URI:  https://github.com/qcexpressvault/qcx-woocommerce
 * Description: Integrate QC Express shipping services with WooCommerce for seamless shipping rate calculation, booking creation, and tracking.
 * Version:     1.0.0
 * Author:      Eriyo Digital
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: qcx-woocommerce
 * Requires PHP: 8.0
 *
 * GitHub Plugin URI: qcexpressvault/qcx-woocommerce
 * Primary Branch: main
 */

if (!defined('ABSPATH')) exit;

define('QCXWC_VER', '1.0.0');

register_activation_hook(__FILE__, function(){
  add_option('qcxwc_settings', [
    'mode'         => 'sandbox', // sandbox|live
    'sandbox_base' => 'https://dev-api.qcexpress.co',
    'live_base'    => 'https://api.qcexpress.co',
    'client_id'    => '',
    'token'        => '',
    'timeout'      => 20,
    'origin_country' => 'NG',
    'origin_city'    => 'Lagos',
    'origin_state'   => 'LA',       // optional
    'origin_postal'  => '100001',
    'origin_addr1'   => '',
    'origin_addr2'   => '',
    'default_doc_type' => 'non_document', // 'document' | 'non_document'
    'default_length' => 10,
    'default_width'  => 10,
    'default_height' => 10,
    'insurance'      => 0,    
    'cache_minutes'  => 3,
    'debug_mode'     => 0,
  ], false);
});

function qcxwc_opts(){ return get_option('qcxwc_settings', []); }
function qcxwc_env(){
  $o = qcxwc_opts();
  $live = ($o['mode'] ?? 'sandbox') === 'live';
  return [
    'base'      => rtrim($live ? ($o['live_base'] ?? '') : ($o['sandbox_base'] ?? ''), '/'),
    'client_id' => (string)($o['client_id'] ?? ''),
    'token'     => (string)($o['token'] ?? ''),
    'timeout'   => max(5, (int)($o['timeout'] ?? 20)),
  ];
}

class QCXWC_Client {
  private string $base; private string $client_id; private string $token; private int $timeout;
  public function __construct(){ $e=qcxwc_env(); $this->base=$e['base']; $this->client_id=$e['client_id']; $this->token=$e['token']; $this->timeout=$e['timeout']; }
  public function request(string $method, string $path, array $body=null, array $query=null){
    if (!$this->base) return new WP_Error('qcx_base','Base URL missing');
    if (!$this->client_id || !$this->token) return new WP_Error('qcx_auth','Client ID or Token missing');
    $url = $this->base.$path; if ($query) $url = add_query_arg($query, $url);
    $args = [
      'method'=>$method,'timeout'=>$this->timeout,
      'headers'=>[
        'ClientID'=>$this->client_id,
        'Authorization'=>'Bearer '.$this->token,
        'Content-Type'=>'application/json','Accept'=>'application/json'
      ],
    ];
    if ($body!==null) $args['body']=wp_json_encode($body);

    // Enhanced logging for debugging
    wc_get_logger()->info('QCX API Request Details', [
      'source' => 'qcxwc_api',
      'method' => $method,
      'url' => $url,
      'headers' => [
        'ClientID' => substr($this->client_id, 0, 8) . '***',
        'Authorization' => 'Bearer ' . substr($this->token, 0, 8) . '***',
        'Content-Type' => 'application/json'
      ],
      'body_size' => $body ? strlen(wp_json_encode($body)) : 0,
      'payload' => $body
    ]);

    $res = wp_remote_request($url,$args);
    if (is_wp_error($res)) {
      wc_get_logger()->error('QCX API Network Error', [
        'source' => 'qcxwc_api',
        'error' => $res->get_error_message(),
        'url' => $url
      ]);
      return $res;
    }

    $code=wp_remote_retrieve_response_code($res);
    $raw=wp_remote_retrieve_body($res);
    $headers = wp_remote_retrieve_headers($res);
    $json=json_decode($raw,true);

    // Enhanced error logging
    if ($code>=400) {
      wc_get_logger()->error('QCX API Error Response', [
        'source' => 'qcxwc_api',
        'method' => $method,
        'url' => $url,
        'status_code' => $code,
        'response_headers' => $headers,
        'response_body_raw' => $raw,
        'response_body_parsed' => $json,
        'request_payload' => $body
      ]);
      return new WP_Error('qcx_http_'.$code,'QCX API error',['status'=>$code,'body'=>$json?:$raw,'headers'=>$headers]);
    }

    // Log successful responses
    wc_get_logger()->info('QCX API Success Response', [
      'source' => 'qcxwc_api',
      'method' => $method,
      'url' => $url,
      'status_code' => $code,
      'response_size' => strlen($raw),
      'response_data' => $json ?? 'non-json'
    ]);

    return $json ?? $raw;
  }

  /**
   * Create a booking with QC Express
   */
  public function create_booking($order_id, $shipping_data = []) {
    $order = wc_get_order($order_id);
    if (!$order) {
      return new WP_Error('qcx_booking_error', 'Invalid order ID');
    }

    // Get shipping methods used
    $shipping_methods = $order->get_shipping_methods();
    $qcx_method = null;
    foreach ($shipping_methods as $method) {
      if (strpos($method->get_method_id(), 'qcxwc_shipping') === 0) {
        $qcx_method = $method;
        break;
      }
    }

    if (!$qcx_method) {
      return new WP_Error('qcx_booking_error', 'No QC Express shipping method found for this order');
    }

    // Extract metadata from the shipping method
    $meta_data = $qcx_method->get_meta_data();
    $qcx_meta = [];
    foreach ($meta_data as $meta) {
      if (strpos($meta->key, 'qcx_') === 0) {
        $qcx_meta[$meta->key] = $meta->value;
      }
    }

    $doc_type = $qcx_meta['qcx_doc_type'] ?? 'non_document';
    $has_insurance = !empty($qcx_meta['qcx_insurance']) ? true : false;
    
    // Determine if this is domestic or export
    $dest_country = $order->get_shipping_country();
    $is_domestic = strtoupper($dest_country) === 'NG';
    $booking_type = $is_domestic ? 'DOMESTIC' : 'EXPORT';

    // Build the booking payload
    $payload = $this->build_booking_payload($order, $booking_type, $doc_type, $has_insurance, $shipping_data);

    // Log the booking attempt
    wc_get_logger()->info('QCX Creating Booking', [
      'source' => 'qcxwc',
      'order_id' => $order_id,
      'booking_type' => $booking_type,
      'doc_type' => $doc_type,
      'insurance' => $has_insurance,
      'payload' => $payload
    ]);

    $response = $this->request('POST', '/api/v1/business/create-booking', $payload);

    if (is_wp_error($response)) {
      wc_get_logger()->error('QCX Booking Failed', [
        'source' => 'qcxwc',
        'order_id' => $order_id,
        'error' => $response->get_error_message()
      ]);
      return $response;
    }

    // Store comprehensive booking data
    $this->persist_booking_payload($order, $response);

    wc_get_logger()->info('QCX Booking Created', [
      'source' => 'qcxwc',
      'order_id' => $order_id,
      'response' => $response
    ]);

    return $response;
  }

  /**
   * Get tracking information for a shipment
   */
  public function get_tracking($tracking_id) {
    if (empty($tracking_id)) {
      return new WP_Error('qcx_tracking_error', 'Tracking ID is required');
    }

    $response = $this->request('GET', '/api/v1/tracking/single', null, ['id' => $tracking_id]);

    if (is_wp_error($response)) {
      wc_get_logger()->error('QCX Tracking Failed', [
        'source' => 'qcxwc',
        'tracking_id' => $tracking_id,
        'error' => $response->get_error_message()
      ]);
      return $response;
    }

    wc_get_logger()->info('QCX Tracking Retrieved', [
      'source' => 'qcxwc',
      'tracking_id' => $tracking_id,
      'response' => $response
    ]);

    return $response;
  }

  /**
   * Cancel a booking (business only)
   */
  public function cancel_booking($booking_id, $reason = '') {
    if (empty($booking_id)) {
      return new WP_Error('missing_booking_id', 'Booking ID is required');
    }

    $payload = [
      'bookingId' => $booking_id,
      'reason' => $reason ?: 'Cancelled by business'
    ];

    wc_get_logger()->info('QCX Cancel Booking Request', [
      'source' => 'qcxwc',
      'booking_id' => $booking_id,
      'reason' => $reason,
      'payload' => $payload
    ]);

    $response = $this->request('POST', '/api/v1/business/cancel-booking', $payload);

    if (is_wp_error($response)) {
      wc_get_logger()->error('QCX Cancel Booking Error', [
        'source' => 'qcxwc',
        'booking_id' => $booking_id,
        'error' => $response->get_error_message(),
        'error_data' => $response->get_error_data()
      ]);
      return $response;
    }

    wc_get_logger()->info('QCX Cancel Booking Success', [
      'source' => 'qcxwc',
      'booking_id' => $booking_id,
      'response' => $response
    ]);

    return $response;
  }

  /**
   * Persist booking payload data and documents to order meta and WordPress attachments
   */
  private function persist_booking_payload($order, array $response) {
    $data = $response['data'] ?? [];

    // Core IDs / URLs
    $order->update_meta_data('_qcx_booking_id', $data['bookingId'] ?? '');
    $order->update_meta_data('_qcx_tracking_id', $data['shipmentMeta']['trackingId'] ?? '');
    $order->update_meta_data('_qcx_tracking_url', $data['shipmentMeta']['trackingUrl'] ?? '');

    // Store complete response for reference
    $order->update_meta_data('_qcx_booking_response', $response);

    // Legacy tracking number for backwards compatibility
    if (isset($response['data']['trackingNumber'])) {
      $order->update_meta_data('_qcx_tracking_number', $response['data']['trackingNumber']);
    }

    // Piece tracking numbers (array)
    $piece_numbers = [];
    foreach (($data['shipmentMeta']['packages'] ?? []) as $pkg) {
      if (!empty($pkg['trackingNumber'])) $piece_numbers[] = $pkg['trackingNumber'];
    }
    if ($piece_numbers) {
      $order->update_meta_data('_qcx_piece_tracking_numbers', $piece_numbers);
    }

    // Save documents as attachments
    $attachment_ids = [];
    foreach (($data['shipmentMeta']['documents'] ?? []) as $idx => $doc) {
      $format = strtoupper($doc['imageFormat'] ?? 'PDF');
      $b64 = $doc['content'] ?? '';
      if (!$b64) continue;

      $bytes = base64_decode($b64);
      if (!$bytes) continue;

      $filename_base = sprintf('qcx-%s-%s-%s.%s',
        $order->get_order_number(),
        $data['shipmentMeta']['trackingId'] ?? 'label',
        str_pad((string)$idx, 2, '0', STR_PAD_LEFT),
        strtolower($format)
      );

      $upload = wp_upload_bits($filename_base, null, $bytes);
      if (!empty($upload['error']) || empty($upload['file'])) continue;

      // Register as attachment so WP knows about it
      $filetype = wp_check_filetype(basename($upload['file']), null);
      $attachment = [
        'post_mime_type' => $filetype['type'] ?? 'application/pdf',
        'post_title' => sanitize_file_name($filename_base),
        'post_content' => '',
        'post_status' => 'inherit',
      ];
      $attach_id = wp_insert_attachment($attachment, $upload['file']);
      if ($attach_id && !is_wp_error($attach_id)) {
        require_once ABSPATH.'wp-admin/includes/image.php';
        $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
        wp_update_attachment_metadata($attach_id, $attach_data);
        $attachment_ids[] = $attach_id;
      }
    }

    if ($attachment_ids) {
      $order->update_meta_data('_qcx_label_attachment_ids', $attachment_ids);
    }

    $order->save();
  }

  /**
   * Build booking payload based on order and shipping type
   */
  private function build_booking_payload($order, $booking_type, $doc_type, $has_insurance, $shipping_data = []) {
    $opts = qcxwc_opts();
    
    // Base payload structure
    $payload = [
      'type' => $booking_type,
      'insurance' => $has_insurance,
      'shipmentData' => $this->build_shipment_data($order, $opts),
      'bookingData' => $this->build_booking_data($order, $doc_type)
    ];

    // Add international section for export shipments
    if ($booking_type === 'EXPORT') {
      $payload['international'] = $this->build_international_data($order, $doc_type);
    }

    return $payload;
  }

  /**
   * Build shipment data section
   */
  private function build_shipment_data($order, $opts) {
    // Build planned shipping date/time
    $tz = wp_timezone();
    $now = new DateTime('now', $tz);
    $offset_min = (int)$tz->getOffset($now) / 60;
    $sign = $offset_min >= 0 ? '+' : '-';
    $hh = str_pad((string)floor(abs($offset_min)/60), 2, '0', STR_PAD_LEFT);
    $mm = str_pad((string)(abs($offset_min)%60), 2, '0', STR_PAD_LEFT);
    $planned = $now->format('Y-m-d\TH:i:s') . " GMT{$sign}{$hh}:{$mm}";

    // Calculate total weight and get largest dimensions
    $total_weight = 0;
    $max_length = (int)($opts['default_length'] ?? 10);
    $max_width = (int)($opts['default_width'] ?? 10);
    $max_height = (int)($opts['default_height'] ?? 10);

    foreach ($order->get_items() as $item) {
      $product = $item->get_product();
      if ($product) {
        $weight = (float)$product->get_weight();
        $length = (float)$product->get_length();
        $width = (float)$product->get_width();
        $height = (float)$product->get_height();
        
        $weight_unit = get_option('woocommerce_weight_unit');
        if ($weight_unit === 'g') $weight = $weight / 1000; // Convert to kg
        
        $total_weight += $weight * $item->get_quantity();
        
        if ($length > $max_length) $max_length = (int)ceil($length);
        if ($width > $max_width) $max_width = (int)ceil($width);
        if ($height > $max_height) $max_height = (int)ceil($height);
      }
    }

    $total_weight = max(0.1, round($total_weight, 3));

    // Build addresses
    $sender = [
      'postalAddress' => [
        'postalCode' => $opts['origin_postal'] ?? '',
        'cityName' => $opts['origin_city'] ?? '',
        'countryCode' => strtoupper($opts['origin_country'] ?? 'NG'),
        'addressLine1' => $opts['origin_addr1'] ?? '',
        'countyName' => $opts['origin_state'] ?? ''
      ],
      'contactInformation' => [
        'phone' => $opts['sender_phone'] ?? '+23490000000',
        'companyName' => $opts['sender_company'] ?? get_bloginfo('name'),
        'fullName' => $opts['sender_name'] ?? 'Store Manager',
        'email' => $opts['sender_email'] ?? get_option('admin_email')
      ]
    ];

    $receiver = [
      'postalAddress' => [
        'postalCode' => $order->get_shipping_postcode() ?: '',
        'cityName' => $order->get_shipping_city() ?: '',
        'countryCode' => strtoupper($order->get_shipping_country()),
        'addressLine1' => $order->get_shipping_address_1() ?: '',
        'countyName' => $order->get_shipping_state() ?: ''
      ],
      'contactInformation' => [
        'phone' => $order->get_shipping_phone() ?: $order->get_billing_phone() ?: '+23490000000',
        'companyName' => $order->get_shipping_company() ?: $order->get_shipping_company() ?: ($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name()),
        'fullName' => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
        'email' => $order->get_billing_email() ?: ''
      ]
    ];

    // Add addressLine2 if available
    if ($address2 = $order->get_shipping_address_2()) {
      $receiver['postalAddress']['addressLine2'] = $address2;
    }
    if (!empty($opts['origin_addr2'])) {
      $sender['postalAddress']['addressLine2'] = $opts['origin_addr2'];
    }

    $packages = [[
      'weight' => $total_weight,
      'dimensions' => [
        'length' => $max_length,
        'width' => $max_width,
        'height' => $max_height
      ]
    ]];

    // Build item description
    $items = [];
    foreach ($order->get_items() as $item) {
      $items[] = $item->get_name();
    }
    $description = implode(', ', array_slice($items, 0, 3));
    if (count($items) > 3) $description .= '...';

    // Calculate declared value as sum of item costs (excluding shipping, taxes, fees)
    $item_total = 0;
    foreach ($order->get_items() as $item) {
      $item_total += $item->get_total();
    }
    $declared_value = max(1, round($item_total, 2));

    $shipment_data = [
      'plannedShippingDateAndTime' => $planned,
      'pickup' => false,
      'declaredValue' => $declared_value,
      'sender' => $sender,
      'receiver' => $receiver,
      'packages' => $packages,
      'description' => $description
    ];

    // Add currency for non-domestic shipments
    if (strtoupper($order->get_shipping_country()) !== 'NG') {
      $shipment_data['declaredValueCurrency'] = $order->get_currency();
    }

    return $shipment_data;
  }

  /**
   * Build booking data section
   */
  private function build_booking_data($order, $doc_type) {
    // Calculate item total (excluding shipping, taxes, fees)
    $item_total = 0;
    foreach ($order->get_items() as $item) {
      $item_total += $item->get_total();
    }
    
    return [
      'category' => 'General', // Could be made configurable
      'shipment_type' => $doc_type === 'document' ? 'DOCUMENT' : 'PACKAGE',
      'value' => max(1, round($item_total, 2))
    ];
  }

  /**
   * Build international data section for export shipments
   */
  private function build_international_data($order, $doc_type) {
    $line_items = [];
    $total_net_weight = 0;
    $total_gross_weight = 0;
    $item_number = 1;

    foreach ($order->get_items() as $item) {
      $product = $item->get_product();
      $quantity = $item->get_quantity();
      $price = $item->get_total() / $quantity;
      
      $weight = $product ? (float)$product->get_weight() : 0.5;
      $weight_unit = get_option('woocommerce_weight_unit');
      if ($weight_unit === 'g') $weight = $weight / 1000;
      $weight = max(0.1, $weight);
      
      $total_net_weight += $weight * $quantity;
      $total_gross_weight += $weight * $quantity;

      // Check for product-specific commodity code
      $commodity_code = '9999999999'; // Default fallback
      if ($product) {
        // Check for custom field/meta for commodity code
        $product_commodity = $product->get_meta('_commodity_code') ?: $product->get_meta('commodity_code');
        if (!empty($product_commodity)) {
          $commodity_code = sanitize_text_field($product_commodity);
        }
      }

      $line_items[] = [
        'number' => $item_number++,
        'quantity' => [
          'unitOfMeasurement' => 'PCS',
          'value' => $quantity
        ],
        'price' => round($price, 2),
        'description' => $item->get_name(),
        'weight' => [
          'netValue' => $weight,
          'grossValue' => $weight
        ],
        'commodityCodes' => [[
          'typeCode' => 'outbound',
          'value' => $commodity_code
        ]],
        'exportReasonType' => 'permanent',
        'manufacturerCountry' => 'NG'
      ];
    }

    return [
      'exportDeclaration' => [
        'lineItems' => $line_items,
        'exportReason' => 'sale', // Could be configurable
        'invoice' => [
          'number' => 'invoice-' . $order->get_order_number(),
          'date' => $order->get_date_created()->format('Y-m-d'),
          'totalNetWeight' => round($total_net_weight, 2),
          'totalGrossWeight' => round($total_gross_weight, 2)
        ],
        'placeOfIncoterm' => $order->get_shipping_city(),
        'exportReasonType' => 'permanent',
        'shipmentType' => 'commercial'
      ]
    ];
  }
}
class QCXWC_Business {
  const CACHE_KEY = 'qcxwc_business_cache';
  const CACHE_TTL = 10 * MINUTE_IN_SECONDS; // cache for 10 minutes

  /** Fetch fresh from API and store */
  public static function refresh(): array|WP_Error {
    $client = new QCXWC_Client();
    $res = $client->request('GET','/api/v1/business/business-info');
    if (is_wp_error($res)) return $res;

    // Extract the data from the API response which has structure: { "data": { ... }, "message": "...", "success": true }
    $businessData = is_array($res) && isset($res['data']) ? $res['data'] : [];
    
    $payload = [
      'fetched_at'   => time(),
      'data'         => $businessData,
    ];
    set_transient(self::CACHE_KEY, $payload, self::CACHE_TTL);
    return $payload;
  }

  /** Get cached (or refresh if missing/expired) */
  public static function get(): array|WP_Error {
    $cache = get_transient(self::CACHE_KEY);
    if ($cache && is_array($cache)) return $cache;
    return self::refresh();
  }

  /** Helper to format currency safely */
  public static function money($amount, $currency = ''): string {
    $amount = is_numeric($amount) ? (float)$amount : 0.0;
    $formatted = number_format($amount, 2, '.', ',');
    return $currency ? "{$currency} {$formatted}" : $formatted;
  }
}



add_action('admin_menu', function(){
  add_submenu_page('woocommerce','QCX Express','QCX Express','manage_woocommerce','qcxwc','qcxwc_settings_page');
  add_submenu_page('woocommerce','QCX Sandbox','QCX Sandbox','manage_woocommerce','qcxwc-sandbox','qcxwc_sandbox_page');
  add_submenu_page(
    'woocommerce',
    __('QCX Business Details','qcx-woocommerce'),
    __('QCX Business','qcx-woocommerce'),
    'manage_woocommerce',
    'qcxwc-business',
    function () {
      if (!current_user_can('manage_woocommerce')) return;

      $notice = '';
      if (!empty($_POST['qcxwc_refresh_business']) && check_admin_referer('qcxwc_business')) {
        $ref = QCXWC_Business::refresh();
        if (is_wp_error($ref)) {
          $notice = '<div class="error"><p><strong>'.esc_html__('Refresh failed:','qcx-woocommerce').'</strong> '.esc_html($ref->get_error_message()).'</p></div>';
        } else {
          $notice = '<div class="updated"><p>'.esc_html__('Business details refreshed.','qcx-woocommerce').'</p></div>';
        }
      }

      $cached = QCXWC_Business::get();
      if (is_wp_error($cached)) {
        echo '<div class="error"><p>'.esc_html($cached->get_error_message()).'</p></div>';
        return;
      }
      $data = $cached['data'] ?? [];
      $when = !empty($cached['fetched_at']) ? date_i18n(get_option('date_format').' '.get_option('time_format'), $cached['fetched_at']) : '';

      // $name        = $data['name'] ?? '';
      $outstanding = $data['outstanding'] ?? 0;
      $currency    = $data['currency'] ?? get_woocommerce_currency();
      $acctBank    = $data['bank'] ?? '';
      $acctNumber  = $data['account_number'] ?? '';
      // $acctName    = $data['account']['name'] ?? ''; // if available
      ?>
      <div class="wrap">
        <h1><?php esc_html_e('QCX Business Details', 'qcx-woocommerce'); ?></h1>
        <?php echo $notice; ?>
        <form method="post">
          <?php wp_nonce_field('qcxwc_business'); ?>
          <p><button class="button" name="qcxwc_refresh_business" value="1"><?php esc_html_e('Refresh from API','qcx-woocommerce'); ?></button></p>
        </form>

        <table class="widefat striped" style="max-width:800px">
          <tbody>
            <!-- <tr><th><?php esc_html_e('Business Name','qcx-woocommerce');?></th><td><?php echo esc_html($name);?></td></tr> -->
            <tr><th><?php esc_html_e('Outstanding','qcx-woocommerce');?></th><td><?php echo esc_html(QCXWC_Business::money($outstanding, $currency));?></td></tr>
            <tr><th><?php esc_html_e('Settlement Account','qcx-woocommerce');?></th>
              <td>
                <?php if ($acctBank || $acctNumber): ?>
                  <div><strong><?php echo esc_html($acctBank);?></strong></div>
                  <div><code><?php echo esc_html($acctNumber);?></code> <button type="button" class="button button-small" onclick="navigator.clipboard.writeText('<?php echo esc_js($acctNumber);?>')"><?php esc_html_e('Copy','qcx-woocommerce');?></button></div>
                <?php else: ?>
                  <em><?php esc_html_e('No account details available.','qcx-woocommerce'); ?></em>
                <?php endif; ?>
              </td>
            </tr>
            <?php if (!empty($data['creditLimit'])): ?>
              <tr><th><?php esc_html_e('Credit Limit','qcx-woocommerce');?></th><td><?php echo esc_html(QCXWC_Business::money($data['creditLimit'], $currency));?></td></tr>
            <?php endif; ?>
            <?php if (!empty($data['balance'])): ?>
              <tr><th><?php esc_html_e('Available Balance','qcx-woocommerce');?></th><td><?php echo esc_html(QCXWC_Business::money($data['balance'], $currency));?></td></tr>
            <?php endif; ?>
            <tr><th><?php esc_html_e('Last Updated','qcx-woocommerce');?></th><td><?php echo esc_html($when ?: __('Never','qcx-woocommerce'));?></td></tr>
          </tbody>
        </table>
      </div>
      <?php
    }
  );
});

function qcxwc_sanitize($in) {
  $o = [];
  $o['mode']           = in_array($in['mode'] ?? '', ['sandbox', 'live']) ? $in['mode'] : 'sandbox';
  $o['sandbox_base']   = esc_url_raw($in['sandbox_base'] ?? '');
  $o['live_base']      = esc_url_raw($in['live_base'] ?? '');
  $o['client_id']      = sanitize_text_field($in['client_id'] ?? '');
  $o['token']          = sanitize_text_field($in['token'] ?? '');
  $o['timeout']        = max(5, (int)($in['timeout'] ?? 20));
  $o['default_doc_type'] = in_array($in['default_doc_type'] ?? '', ['document', 'non_document']) ? $in['default_doc_type'] : 'non_document';
  $o['origin_country'] = sanitize_text_field($in['origin_country'] ?? 'NG');
  $o['origin_city']    = sanitize_text_field($in['origin_city'] ?? '');
  $o['origin_state']   = sanitize_text_field($in['origin_state'] ?? '');
  $o['origin_postal']  = sanitize_text_field($in['origin_postal'] ?? '');
  $o['origin_addr1']   = sanitize_text_field($in['origin_addr1'] ?? '');
  $o['origin_addr2']   = sanitize_text_field($in['origin_addr2'] ?? '');
  $o['sender_name']    = sanitize_text_field($in['sender_name'] ?? '');
  $o['sender_company'] = sanitize_text_field($in['sender_company'] ?? '');
  $o['sender_phone']   = sanitize_text_field($in['sender_phone'] ?? '');
  $o['sender_email']   = sanitize_email($in['sender_email'] ?? '');
  $o['default_length'] = max(1, (int)($in['default_length'] ?? 10));
  $o['default_width']  = max(1, (int)($in['default_width']  ?? 10));
  $o['default_height'] = max(1, (int)($in['default_height'] ?? 10));
  $o['insurance']      = empty($in['insurance']) ? 0 : 1;
  $o['cache_minutes']  = max(0, (int)($in['cache_minutes'] ?? 3));
  $o['debug_mode']     = empty($in['debug_mode']) ? 0 : 1;
  $o['auto_booking']   = in_array($in['auto_booking'] ?? '', ['disabled', 'processing', 'completed', 'both']) ? $in['auto_booking'] : 'processing';
  return $o;
}function qcxwc_settings_page(){
  if (!current_user_can('manage_woocommerce')) return;
  if (!empty($_POST['qcxwc_save']) && check_admin_referer('qcxwc_settings')) {
    update_option('qcxwc_settings', qcxwc_sanitize($_POST));
    echo '<div class="updated"><p>Saved.</p></div>';
  }
  $o=qcxwc_opts();
  ?>
  <div class="wrap"><h1>QC Express Settings</h1>
    <form method="post"><?php wp_nonce_field('qcxwc_settings'); ?>
      <table class="form-table">
        <tr><th>Mode</th><td>
          <select name="mode">
            <option value="sandbox" <?php selected(($o['mode']??'sandbox'),'sandbox');?>>Sandbox</option>
            <option value="live" <?php selected(($o['mode']??'sandbox'),'live');?>>Live</option>
          </select></td></tr>
        <tr><th>Sandbox Base URL</th><td><input type="url" class="regular-text" name="sandbox_base" value="<?php echo esc_attr($o['sandbox_base']??''); ?>"></td></tr>
        <tr><th>Live Base URL</th><td><input type="url" class="regular-text" name="live_base" value="<?php echo esc_attr($o['live_base']??''); ?>"></td></tr>
        <tr><th>Client ID</th><td><input type="text" class="regular-text" name="client_id" value="<?php echo esc_attr($o['client_id']??''); ?>"></td></tr>
        <tr><th>Token</th><td><input type="text" class="regular-text" name="token" value="<?php echo esc_attr($o['token']??''); ?>"></td></tr>
        <tr><th>HTTP Timeout (s)</th><td><input type="number" min="5" name="timeout" value="<?php echo esc_attr($o['timeout']??20); ?>"></td></tr>
        <tr><th><label>Default Document Type</label></th>
  <td>
    <select name="default_doc_type">
      <option value="document" <?php selected(($o['default_doc_type']??'non_document'),'document');?>>Document</option>
      <option value="non_document" <?php selected(($o['default_doc_type']??'non_document'),'non_document');?>>Non-document</option>
    </select>
    <p class="description">You can override per product via a shipping class later.</p>
  </td>
</tr>
<tr><th colspan="2"><h3>Origin (Shipper)</h3></th></tr>
<tr><th>Country</th><td><input name="origin_country" value="<?php echo esc_attr($o['origin_country']??'NG'); ?>" /></td></tr>
<tr><th>City</th><td><input name="origin_city" value="<?php echo esc_attr($o['origin_city']??'Lagos'); ?>" /></td></tr>
<tr><th>State</th><td><input name="origin_state" value="<?php echo esc_attr($o['origin_state']??'LA'); ?>" /></td></tr>
<tr><th>Postal Code</th><td><input name="origin_postal" value="<?php echo esc_attr($o['origin_postal']??'100001'); ?>" /></td></tr>
<tr><th>Address 1</th><td><input class="regular-text" name="origin_addr1" value="<?php echo esc_attr($o['origin_addr1']??''); ?>" /></td></tr>
<tr><th>Address 2</th><td><input class="regular-text" name="origin_addr2" value="<?php echo esc_attr($o['origin_addr2']??''); ?>" /></td></tr>
<tr><th colspan="2"><h3>Sender Contact Information</h3></th></tr>
<tr><th>Sender Name</th><td><input class="regular-text" name="sender_name" value="<?php echo esc_attr($o['sender_name']??'Store Manager'); ?>" /></td></tr>
<tr><th>Company Name</th><td><input class="regular-text" name="sender_company" value="<?php echo esc_attr($o['sender_company']??get_bloginfo('name')); ?>" /></td></tr>
<tr><th>Phone Number</th><td><input class="regular-text" name="sender_phone" value="<?php echo esc_attr($o['sender_phone']??'+23490000000'); ?>" /></td></tr>
<tr><th>Email Address</th><td><input type="email" class="regular-text" name="sender_email" value="<?php echo esc_attr($o['sender_email']??get_option('admin_email')); ?>" /></td></tr>
<tr><th colspan="2"><h3>Package Defaults</h3></th></tr>
<tr><th>Default Package Dimensions (cm)</th>
  <td>
    L <input type="number" name="default_length" step="1" min="1" value="<?php echo esc_attr($o['default_length']??10); ?>" style="width:90px;" />
    W <input type="number" name="default_width"  step="1" min="1" value="<?php echo esc_attr($o['default_width']??10); ?>" style="width:90px;" />
    H <input type="number" name="default_height" step="1" min="1" value="<?php echo esc_attr($o['default_height']??10); ?>" style="width:90px;" />
  </td>
</tr>
<tr><th>Insurance</th>
  <td><label><input type="checkbox" name="insurance" value="1" <?php checked(!empty($o['insurance'])); ?>/> Include insurance in quotes</label></td>
</tr>
<tr><th>Quote Cache (minutes)</th>
  <td>
    <input type="number" name="cache_minutes" min="0" max="60" value="<?php echo esc_attr($o['cache_minutes']??3); ?>" style="width:90px;" />
    <p class="description">Cache shipping quotes for this many minutes to improve performance.</p>
  </td>
</tr>
<tr><th>Debug Mode</th>
  <td>
    <label><input type="checkbox" name="debug_mode" value="1" <?php checked(!empty($o['debug_mode'])); ?>/> Enable debug logging</label>
    <p class="description">Log shipping quote requests and responses for troubleshooting.</p>
  </td>
</tr>
<tr><th colspan="2"><h3>Booking Automation</h3></th></tr>
<tr><th>Auto-create Bookings</th>
  <td>
    <select name="auto_booking">
      <option value="disabled" <?php selected(($o['auto_booking']??'processing'),'disabled');?>>Disabled</option>
      <option value="processing" <?php selected(($o['auto_booking']??'processing'),'processing');?>>When order status is Processing</option>
      <option value="completed" <?php selected(($o['auto_booking']??'processing'),'completed');?>>When order status is Completed</option>
      <option value="both" <?php selected(($o['auto_booking']??'processing'),'both');?>>Both Processing and Completed</option>
    </select>
    <p class="description">Automatically create QC Express bookings when orders reach these statuses.</p>
  </td>
</tr>
      </table>
      <p><button class="button button-primary" name="qcxwc_save" value="1">Save</button></p>
    </form>
  </div>
  <?php
}

function qcxwc_sandbox_page(){
  if (!current_user_can('manage_woocommerce')) return;
  $out='';
  if (!empty($_POST['qcx_action']) && check_admin_referer('qcx_sandbox')) {
    $client=new QCXWC_Client();
    switch ($_POST['qcx_action']) {
      case 'ping': 
        $out = $client->request('GET','/api/v1/business/business-info'); 
        break;
        
      case 'quote':
        // Build a proper shipping quote payload like the shipping method does
        $opts = qcxwc_opts();
        $payload = [
          'document' => 'non_document',
          'deliveryType' => 'export',
          'customerDetails' => [
            'shipperDetails' => [
              'postalCode'   => $opts['origin_postal'] ?? '100001',
              'cityName'     => $opts['origin_city'] ?? 'Lagos',
              'addressLine1' => $opts['origin_addr1'] ?? 'Test Address',
              'countryCode'  => strtoupper($opts['origin_country'] ?? 'NG'),
            ],
            'receiverDetails' => [
              'postalCode'   => '10001',
              'cityName'     => 'New York',
              'addressLine1' => '123 Test Street',
              'countryCode'  => 'US',
            ]
          ],
          'plannedShippingDateAndTime' => date('Y-m-d\TH:i:s') . ' GMT+01:00',
          'packages' => [[
            'weight' => 1.0,
            'dimensions' => [
              'length' => 10,
              'width'  => 10,
              'height' => 10,
            ],
          ]],
          'insurance' => false,
          'monetaryAmount' => [[
            'typeCode' => 'declaredValue',
            'value'    => 100.00,
            'currency' => 'NGN',
          ]],
        ];
        
        // Try both endpoints
        $out = $client->request('POST', '/api/v1/shipping/quote', $payload);
        if (is_wp_error($out)) {
          $out = ['error_shipping_quote' => $out->get_error_message()];
          $out['trying_price_fetch'] = $client->request('POST', '/api/v1/price/fetch', $payload);
        }
        break;
        
      case 'test_booking':
        // Create a test booking payload
        $test_payload = [
          'type' => 'EXPORT',
          'insurance' => false,
          'shipmentData' => [
            'plannedShippingDateAndTime' => date('Y-m-d\TH:i:s') . ' GMT+01:00',
            'pickup' => false,
            'declaredValue' => 100,
            'declaredValueCurrency' => 'NGN',
            'sender' => [
              'postalAddress' => [
                'postalCode' => $opts['origin_postal'] ?? '102216',
                'cityName' => $opts['origin_city'] ?? 'Lagos',
                'countryCode' => strtoupper($opts['origin_country'] ?? 'NG'),
                'addressLine1' => $opts['origin_addr1'] ?? 'Test Address',
                'countyName' => $opts['origin_state'] ?? 'Lagos'
              ],
              'contactInformation' => [
                'phone' => $opts['sender_phone'] ?? '+23490000000',
                'companyName' => $opts['sender_company'] ?? 'Test Company',
                'fullName' => $opts['sender_name'] ?? 'Test Sender',
                'email' => $opts['sender_email'] ?? 'test@example.com'
              ]
            ],
            'receiver' => [
              'postalAddress' => [
                'postalCode' => '32084',
                'cityName' => 'St. Augustine',
                'countryCode' => 'US',
                'addressLine1' => 'Test Receiver Address',
                'countyName' => 'Florida'
              ],
              'contactInformation' => [
                'phone' => '+1234567890',
                'companyName' => 'Test Receiver Company',
                'fullName' => 'Test Receiver',
                'email' => 'receiver@example.com'
              ]
            ],
            'packages' => [[
              'weight' => 2,
              'dimensions' => [
                'length' => 10,
                'width' => 10,
                'height' => 10
              ]
            ]],
            'description' => 'Test Package'
          ],
          'bookingData' => [
            'category' => 'Electronics',
            'shipment_type' => 'PACKAGE',
            'value' => 100
          ],
          'international' => [
            'exportDeclaration' => [
              'lineItems' => [[
                'number' => 1,
                'quantity' => [
                  'unitOfMeasurement' => 'PCS',
                  'value' => 1
                ],
                'price' => 100,
                'description' => 'Test Item',
                'weight' => [
                  'netValue' => 2,
                  'grossValue' => 2
                ],
                'commodityCodes' => [[
                  'typeCode' => 'outbound',
                  'value' => '8538908180'
                ]],
                'exportReasonType' => 'permanent',
                'manufacturerCountry' => 'NG'
              ]],
              'exportReason' => 'sale',
              'invoice' => [
                'number' => 'test-invoice-' . time(),
                'date' => date('Y-m-d'),
                'totalNetWeight' => 2,
                'totalGrossWeight' => 2
              ],
              'placeOfIncoterm' => 'St. Augustine',
              'exportReasonType' => 'permanent',
              'shipmentType' => 'commercial'
            ]
          ]
        ];
        
        $out = $client->request('POST', '/api/v1/business/create-booking', $test_payload);
        break;
        
      case 'debug_booking':
        // Enhanced debug booking with detailed logging
        $test_payload = [
          'type' => 'DOMESTIC',
          'insurance' => false, // Ensure it's boolean
          'shipmentData' => [
            'plannedShippingDateAndTime' => date('Y-m-d\TH:i:s') . ' GMT+01:00',
            'pickup' => false,
            'declaredValue' => 50000,
            'sender' => [
              'postalAddress' => [
                'postalCode' => $opts['origin_postal'] ?? '100001',
                'cityName' => $opts['origin_city'] ?? 'Lagos',
                'countryCode' => strtoupper($opts['origin_country'] ?? 'NG'),
                'addressLine1' => $opts['origin_addr1'] ?? 'Test Sender Address',
                'addressLine2' => $opts['origin_addr2'] ?: '-', // Ensure not empty
                'countyName' => $opts['origin_state'] ?? 'Lagos'
              ],
              'contactInformation' => [
                'phone' => $opts['sender_phone'] ?? '+23490000000',
                'companyName' => $opts['sender_company'] ?? 'Test Company',
                'fullName' => $opts['sender_name'] ?? 'Test Sender',
                'email' => $opts['sender_email'] ?? 'test@example.com'
              ]
            ],
            'receiver' => [
              'postalAddress' => [
                'postalCode' => '100001',
                'cityName' => 'Abuja',
                'countryCode' => 'NG',
                'addressLine1' => 'Test Receiver Address',
                'addressLine2' => '-', // Ensure not empty
                'countyName' => 'FCT'
              ],
              'contactInformation' => [
                'phone' => '+2348000000000',
                'companyName' => 'Test Receiver Company',
                'fullName' => 'Test Receiver',
                'email' => 'receiver@example.com'
              ]
            ],
            'packages' => [[
              'weight' => 1.5,
              'dimensions' => [
                'length' => 10,
                'width' => 10,
                'height' => 10
              ]
            ]],
            'description' => 'Test Package Description'
          ],
          'bookingData' => [
            'category' => 'General',
            'shipment_type' => 'PACKAGE',
            'value' => 50000
          ]
        ];
        
        // Log the payload before sending
        wc_get_logger()->info('QCX Debug Booking Payload', [
          'source' => 'qcxwc_debug',
          'payload' => $test_payload,
          'validation_checks' => [
            'insurance_type' => gettype($test_payload['insurance']),
            'insurance_value' => $test_payload['insurance'],
            'sender_address2_present' => !empty($test_payload['shipmentData']['sender']['postalAddress']['addressLine2']),
            'receiver_address2_present' => !empty($test_payload['shipmentData']['receiver']['postalAddress']['addressLine2'])
          ]
        ]);
        
        $out = $client->request('POST', '/api/v1/business/create-booking', $test_payload);
        break;
    }
  }
  ?>
  <div class="wrap"><h1>QCX Sandbox</h1>
    <form method="post"><?php wp_nonce_field('qcx_sandbox'); ?>
      <p><button class="button" name="qcx_action" value="ping">Get Business Details</button>
         <button class="button" name="qcx_action" value="quote">Test Quote</button>
         <button class="button" name="qcx_action" value="test_booking">Test Booking</button>
         <button class="button button-primary" name="qcx_action" value="debug_booking">🔍 Debug Booking (Enhanced)</button></p>
    </form>
    <?php if ($out!=='') : ?>
      <h2>Response</h2>
      <div style="background:#f9f9f9;border:1px solid #ddd;padding:15px;margin:15px 0;border-radius:5px;">
        <h3>Raw Response:</h3>
        <pre style="background:#111;color:#0f0;padding:12px;overflow:auto;border-radius:3px;"><?php echo esc_html(is_string($out)?$out:wp_json_encode($out, JSON_PRETTY_PRINT)); ?></pre>
        
        <?php if (is_array($out) && isset($out['errors'])): ?>
          <h3 style="color:#d63638;">Error Details:</h3>
          <div style="background:#ffeeee;border:1px solid #d63638;padding:10px;border-radius:3px;">
            <?php 
            foreach ($out['errors'] as $error_key => $error_messages) {
              echo '<strong>' . esc_html($error_key) . ':</strong><br>';
              foreach ((array)$error_messages as $msg) {
                echo '• ' . esc_html($msg) . '<br>';
              }
            }
            if (isset($out['error_data'])) {
              echo '<h4>Additional Error Data:</h4>';
              echo '<pre style="font-size:11px;">' . esc_html(wp_json_encode($out['error_data'], JSON_PRETTY_PRINT)) . '</pre>';
            }
            ?>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>
    
    <div style="background:#fff3cd;border:1px solid #ffeaa7;padding:15px;margin:15px 0;border-radius:5px;">
      <h3>🔍 Debug Tips:</h3>
      <p><strong>Check Logs:</strong> Go to WooCommerce → Status → Logs and look for <code>qcxwc-</code> files for detailed API request/response info.</p>
      <p><strong>Common Issues:</strong></p>
      <ul>
        <li><strong>Status 422:</strong> Validation error - check required fields like addressLine2</li>
        <li><strong>Status 401:</strong> Authentication error - verify Client ID and Token</li>
        <li><strong>Status 500:</strong> Server error - check payload format and API documentation</li>
      </ul>
    </div>
  </div>
  <?php
}

// require_once QCXWC_DIR.'includes/class-qcxwc-business.php';

// Register shipping method
add_action('woocommerce_shipping_init', function() {
  if (!class_exists('QCXWC_Shipping_Method')) {
    require_once __DIR__ . '/includes/class-qcxwc-shipping-method.php';
  }
});

add_filter('woocommerce_shipping_methods', function($methods) {
  $methods['qcxwc_shipping'] = 'QCXWC_Shipping_Method';
  return $methods;
});


// Add booking functionality to WooCommerce orders
add_action('woocommerce_order_status_processing', 'qcxwc_create_booking_on_processing');
add_action('woocommerce_order_status_completed', 'qcxwc_create_booking_on_completed');

function qcxwc_create_booking_on_processing($order_id) {
  qcxwc_maybe_create_booking($order_id, 'processing');
}

function qcxwc_create_booking_on_completed($order_id) {
  qcxwc_maybe_create_booking($order_id, 'completed');
}

function qcxwc_maybe_create_booking($order_id, $trigger) {
  $order = wc_get_order($order_id);
  if (!$order) return;

  // Check if booking already exists
  if ($order->get_meta('_qcx_booking_id') || $order->get_meta('_qcx_booking_response')) {
    return; // Booking already created
  }

  // Check if order uses QC Express shipping
  $has_qcx_shipping = false;
  foreach ($order->get_shipping_methods() as $method) {
    if (strpos($method->get_method_id(), 'qcxwc_shipping') === 0) {
      $has_qcx_shipping = true;
      break;
    }
  }

  if (!$has_qcx_shipping) {
    return; // No QC Express shipping method
  }

  // Check settings for auto-booking
  $opts = qcxwc_opts();
  $auto_booking = $opts['auto_booking'] ?? 'processing';
  
  if ($auto_booking !== $trigger && $auto_booking !== 'both') {
    return; // Auto-booking not enabled for this trigger
  }

  // Create the booking
  $client = new QCXWC_Client();
  $result = $client->create_booking($order_id);

  if (is_wp_error($result)) {
    // Add order note about booking failure
    $order->add_order_note(
      sprintf(
        __('❌ QC Express booking failed: %s', 'qcx-woocommerce'),
        $result->get_error_message()
      )
    );
  } else {
    // Add order note about successful booking with new tracking info
    $booking_id = $order->get_meta('_qcx_booking_id');
    $tracking_id = $order->get_meta('_qcx_tracking_id');
    $tracking_url = $order->get_meta('_qcx_tracking_url');
    
    $note_parts = ['✅ QC Express booking created successfully'];
    
    if ($booking_id) {
      $note_parts[] = 'Booking ID: ' . $booking_id;
    }
    
    if ($tracking_id) {
      $note_parts[] = 'Tracking: ' . $tracking_id;
      $custom_url = qcxwc_get_tracking_url($tracking_id);
      if ($custom_url) {
        $note_parts[] = 'Track at: ' . $custom_url;
      }
    }
    
    $order->add_order_note(implode(' | ', $note_parts));
  }
}

// Helper function to generate custom tracking URL
function qcxwc_get_tracking_url($tracking_id) {
  if (!$tracking_id) return null;
  return home_url('qc-track/' . $tracking_id);
}

// Add QC Express info to order admin details
add_action('woocommerce_admin_order_data_after_order_details', function($order){
  $tracking = $order->get_meta('_qcx_tracking_id');
  $url = $order->get_meta('_qcx_tracking_url');
  $pieces = (array)$order->get_meta('_qcx_piece_tracking_numbers');
  $attachs = (array)$order->get_meta('_qcx_label_attachment_ids');
  $booking_id = $order->get_meta('_qcx_booking_id');

  if (!$tracking && !$attachs && !$booking_id) return;

  echo '<div class="address"><h3>QC Express</h3><p>';
  
  if ($booking_id) {
    echo '<strong>Booking ID:</strong> '.esc_html($booking_id).'<br>';
  }
  
  if ($tracking) {
    echo '<strong>Master Tracking:</strong> '.esc_html($tracking);
    $custom_url = qcxwc_get_tracking_url($tracking);
    if ($custom_url) echo ' — <a href="'.esc_url($custom_url).'" target="_blank">Track</a>';
    echo '<br>';
  }
  
  if ($pieces) {
    echo '<strong>Pieces:</strong> '.esc_html(implode(', ', $pieces)).'<br>';
  }
  
  if ($attachs) {
    echo '<strong>Documents:</strong><br>';
    foreach ($attachs as $id) {
      $link = wp_get_attachment_url($id);
      $title = get_the_title($id);
      echo '• <a href="'.esc_url($link).'" target="_blank">'.esc_html($title ?: 'Shipping Label').'</a><br>';
    }
  }
  echo '</p></div>';
});

// Show QC Express tracking to customers on order details page
add_action('woocommerce_order_details_after_order_table', function($order){
  if (! $order instanceof WC_Order) return;
  $tracking = $order->get_meta('_qcx_tracking_id');
  $url = $order->get_meta('_qcx_tracking_url');
  $attachs = (array)$order->get_meta('_qcx_label_attachment_ids');
  if (!$tracking && !$attachs) return;

  echo '<section class="woocommerce-order-details"><h2>Shipping (QC Express)</h2><p>';
  if ($tracking) {
    echo '<strong>Tracking:</strong> '.esc_html($tracking);
    $custom_url = qcxwc_get_tracking_url($tracking);
    if ($custom_url) echo ' — <a href="'.esc_url($custom_url).'" target="_blank" rel="noopener">Track shipment</a>';
    echo '<br>';
  }
  if ($attachs) {
    echo '<strong>Documents:</strong><br>';
    foreach ($attachs as $id) {
      $link = wp_get_attachment_url($id);
      $title = get_the_title($id);
      echo '• <a href="'.esc_url($link).'" target="_blank" rel="noopener">'.esc_html($title ?: 'Shipping Label').'</a><br>';
    }
  }
  echo '</p></section>';
}, 10, 1);

// Attach shipping labels to WooCommerce emails
add_filter('woocommerce_email_attachments', function($attachments, $email_id, $order){
  if (! $order instanceof WC_Order) return $attachments;

  // Only for these emails:
  $targets = ['customer_processing_order','customer_completed_order'];
  if (!in_array($email_id, $targets, true)) return $attachments;

  $attach_ids = (array)$order->get_meta('_qcx_label_attachment_ids');
  foreach ($attach_ids as $id) {
    $path = get_attached_file($id);
    if ($path && file_exists($path)) $attachments[] = $path;
  }
  return $attachments;
}, 10, 3);

// Add manual booking button to order admin
add_action('woocommerce_order_item_add_action_buttons', 'qcxwc_add_booking_button');

function qcxwc_add_booking_button($order) {
  // Check if order uses QC Express shipping
  $has_qcx_shipping = false;
  foreach ($order->get_shipping_methods() as $method) {
    if (strpos($method->get_method_id(), 'qcxwc_shipping') === 0) {
      $has_qcx_shipping = true;
      break;
    }
  }

  if (!$has_qcx_shipping) return;

  $booking_id = $order->get_meta('_qcx_booking_id');
  $tracking_id = $order->get_meta('_qcx_tracking_id');
  $tracking_url = $order->get_meta('_qcx_tracking_url');
  $attachments = (array)$order->get_meta('_qcx_label_attachment_ids');
  $is_cancelled = $order->get_meta('_qcx_booking_cancelled');
  $cancellation_reason = $order->get_meta('_qcx_cancellation_reason');
  $cancellation_date = $order->get_meta('_qcx_cancellation_date');

  if ($booking_id) {
    if ($is_cancelled) {
      echo '<div class="qcx-booking-status" style="margin: 10px 0; padding: 15px; background: #ffebee; border-left: 4px solid #f44336; border-radius: 3px;">';
      echo '<strong>' . __('❌ QC Express Booking Cancelled', 'qcx-woocommerce') . '</strong><br>';
    } else {
      echo '<div class="qcx-booking-status" style="margin: 10px 0; padding: 15px; background: #f0f8ff; border-left: 4px solid #0073aa; border-radius: 3px;">';
      echo '<strong>' . __('✓ QC Express Booking Created', 'qcx-woocommerce') . '</strong><br>';
    }
    echo '<div style="margin-top: 8px;">';
    echo '<strong>' . __('Booking ID:', 'qcx-woocommerce') . '</strong> <code>' . esc_html($booking_id) . '</code><br>';
    
    if ($is_cancelled) {
      echo '<strong>' . __('Cancelled:', 'qcx-woocommerce') . '</strong> ' . esc_html($cancellation_date) . '<br>';
      echo '<strong>' . __('Reason:', 'qcx-woocommerce') . '</strong> ' . esc_html($cancellation_reason) . '<br>';
    }
    
    if ($tracking_id) {
      echo '<strong>' . __('Tracking ID:', 'qcx-woocommerce') . '</strong> <code>' . esc_html($tracking_id) . '</code>';
      $custom_url = qcxwc_get_tracking_url($tracking_id);
      if ($custom_url) {
        echo ' <a href="' . esc_url($custom_url) . '" target="_blank" class="button button-small">' . __('Track', 'qcx-woocommerce') . '</a>';
      }
      echo '<br>';
    }
    
    if ($attachments) {
      echo '<strong>' . __('Documents:', 'qcx-woocommerce') . '</strong> ';
      $links = [];
      foreach ($attachments as $id) {
        $link = wp_get_attachment_url($id);
        $title = get_the_title($id);
        $links[] = '<a href="' . esc_url($link) . '" target="_blank">' . esc_html($title ?: 'Label') . '</a>';
      }
      echo implode(' | ', $links);
    }
    
    // Add cancel booking button (only if not already cancelled)
    if (!$is_cancelled) {
      echo '<div style="margin-top: 10px;">';
      echo '<button type="button" class="button button-secondary qcx-cancel-booking" data-order-id="' . $order->get_id() . '" data-booking-id="' . esc_attr($booking_id) . '">';
      echo __('❌ Cancel Booking', 'qcx-woocommerce');
      echo '</button>';
      echo ' <span class="description">' . __('Cancel this QC Express booking', 'qcx-woocommerce') . '</span>';
      echo '</div>';
    }
    
    echo '</div></div>';
  } else {
    echo '<button type="button" class="button button-primary qcx-create-booking" data-order-id="' . $order->get_id() . '">';
    echo __('📦 Create QC Express Booking', 'qcx-woocommerce');
    echo '</button>';
    echo '<p class="description">' . __('Create a shipping booking with QC Express and generate shipping labels.', 'qcx-woocommerce') . '</p>';
  }
}

// Add AJAX handler for manual booking creation
add_action('wp_ajax_qcxwc_create_booking', 'qcxwc_ajax_create_booking');

function qcxwc_ajax_create_booking() {
  check_ajax_referer('qcxwc_create_booking', 'nonce');
  
  if (!current_user_can('edit_shop_orders')) {
    wp_die(__('Insufficient permissions', 'qcx-woocommerce'));
  }

  $order_id = intval($_POST['order_id']);
  $order = wc_get_order($order_id);
  
  if (!$order) {
    wp_send_json_error(__('Invalid order ID', 'qcx-woocommerce'));
  }

  $client = new QCXWC_Client();
  $result = $client->create_booking($order_id);

  if (is_wp_error($result)) {
    wp_send_json_error($result->get_error_message());
  } else {
    // Get the newly stored tracking information
    $booking_id = $order->get_meta('_qcx_booking_id');
    $tracking_id = $order->get_meta('_qcx_tracking_id');
    $tracking_number = $order->get_meta('_qcx_tracking_number'); // Legacy field
    
    $message = __('Booking created successfully!', 'qcx-woocommerce');
    if ($booking_id) {
      $message .= ' Booking ID: ' . $booking_id;
    }
    if ($tracking_id) {
      $message .= ' | Tracking: ' . $tracking_id;
    } elseif ($tracking_number) {
      $message .= ' | Tracking: ' . $tracking_number;
    }
    
    wp_send_json_success([
      'message' => $message,
      'booking_id' => $booking_id,
      'tracking_id' => $tracking_id,
      'tracking_number' => $tracking_number
    ]);
  }
}

// Add AJAX handler for manual booking cancellation
add_action('wp_ajax_qcxwc_cancel_booking', 'qcxwc_ajax_cancel_booking');

function qcxwc_ajax_cancel_booking() {
  check_ajax_referer('qcxwc_cancel_booking', 'nonce');
  
  if (!current_user_can('edit_shop_orders')) {
    wp_die(__('Insufficient permissions', 'qcx-woocommerce'));
  }

  $order_id = intval($_POST['order_id']);
  $booking_id = sanitize_text_field($_POST['booking_id']);
  $reason = sanitize_text_field($_POST['reason']);
  
  $order = wc_get_order($order_id);
  
  if (!$order) {
    wp_send_json_error(__('Invalid order ID', 'qcx-woocommerce'));
  }

  if (empty($booking_id)) {
    wp_send_json_error(__('Invalid booking ID', 'qcx-woocommerce'));
  }

  $client = new QCXWC_Client();
  $result = $client->cancel_booking($booking_id, $reason);

  if (is_wp_error($result)) {
    wp_send_json_error($result->get_error_message());
  } else {
    // Update order meta to reflect cancellation
    $order->update_meta_data('_qcx_booking_cancelled', true);
    $order->update_meta_data('_qcx_cancellation_reason', $reason);
    $order->update_meta_data('_qcx_cancellation_date', current_time('mysql'));
    $order->save();
    
    // Add order note
    $order->add_order_note(sprintf(
      __('QC Express booking cancelled. Booking ID: %s | Reason: %s', 'qcx-woocommerce'),
      $booking_id,
      $reason
    ));
    
    wp_send_json_success([
      'message' => __('Booking cancelled successfully!', 'qcx-woocommerce'),
      'booking_id' => $booking_id,
      'reason' => $reason
    ]);
  }
}

// Add JavaScript for manual booking button
add_action('admin_footer', function() {
  global $pagenow;
  if ($pagenow !== 'post.php' && $pagenow !== 'admin.php') return;
  if (!isset($_GET['post']) && !isset($_GET['id'])) return;
  ?>
  <script>
  jQuery(document).ready(function($) {
    $('.qcx-create-booking').on('click', function(e) {
      e.preventDefault();
      
      var $button = $(this);
      var orderId = $button.data('order-id');
      
      $button.prop('disabled', true).html('🔄 Creating booking...');
      
      $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
          action: 'qcxwc_create_booking',
          order_id: orderId,
          nonce: '<?php echo wp_create_nonce('qcxwc_create_booking'); ?>'
        },
        success: function(response) {
          if (response.success) {
            alert('✓ ' + response.data.message);
            location.reload();
          } else {
            alert('❌ Error: ' + response.data);
            $button.prop('disabled', false).html('📦 Create QC Express Booking');
          }
        },
        error: function() {
          alert('❌ Network error occurred');
          $button.prop('disabled', false).html('📦 Create QC Express Booking');
        }
      });
    });

    // Cancel booking handler
    $('.qcx-cancel-booking').on('click', function(e) {
      e.preventDefault();
      
      var $button = $(this);
      var orderId = $button.data('order-id');
      var bookingId = $button.data('booking-id');
      
      var reason = prompt('Please enter cancellation reason:', 'Cancelled by business');
      if (reason === null) return; // User cancelled
      
      if (!confirm('Are you sure you want to cancel this QC Express booking?')) {
        return;
      }
      
      $button.prop('disabled', true).html('🔄 Cancelling...');
      
      $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
          action: 'qcxwc_cancel_booking',
          order_id: orderId,
          booking_id: bookingId,
          reason: reason,
          nonce: '<?php echo wp_create_nonce('qcxwc_cancel_booking'); ?>'
        },
        success: function(response) {
          if (response.success) {
            alert('✓ ' + response.data.message);
            location.reload();
          } else {
            alert('❌ Error: ' + response.data);
            $button.prop('disabled', false).html('❌ Cancel Booking');
          }
        },
        error: function() {
          alert('❌ Network error occurred');
          $button.prop('disabled', false).html('❌ Cancel Booking');
        }
      });
    });
  });
  </script>
  <style>
  .qcx-booking-status {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .qcx-booking-status code {
    background: #fff;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 11px;
    color: #0073aa;
  }
  .qcx-create-booking {
    font-size: 14px !important;
    line-height: 1.4 !important;
    padding: 8px 16px !important;
  }
  </style>
  <?php
});

// Add tracking page rewrite rules and handlers
add_action('init', function() {
  add_rewrite_rule('^qc-track/([^/]*)/?', 'index.php?qcx_tracking_id=$matches[1]', 'top');
});

add_filter('query_vars', function($vars) {
  $vars[] = 'qcx_tracking_id';
  return $vars;
});

// Flush rewrite rules on plugin activation
register_activation_hook(__FILE__, function() {
  add_rewrite_rule('^qc-track/([^/]*)/?', 'index.php?qcx_tracking_id=$matches[1]', 'top');
  flush_rewrite_rules();
});

add_action('template_redirect', function() {
  $tracking_id = get_query_var('qcx_tracking_id');
  if ($tracking_id) {
    qcxwc_display_tracking_page($tracking_id);
    exit;
  }
});

function qcxwc_display_tracking_page($tracking_id) {
  $client = new QCXWC_Client();
  $tracking_data = $client->get_tracking($tracking_id);
  
  get_header();
  ?>
  <div class="qcx-tracking-page" style="max-width: 800px; margin: 0 auto; padding: 20px;">
    <h1><?php _e('Track Your Shipment', 'qcx-woocommerce'); ?></h1>
    
    <?php if (is_wp_error($tracking_data)): ?>
      <div class="qcx-error" style="background: #ffebee; border: 1px solid #f44336; padding: 15px; border-radius: 4px; color: #c62828;">
        <h3><?php _e('Tracking Error', 'qcx-woocommerce'); ?></h3>
        <p><?php echo esc_html($tracking_data->get_error_message()); ?></p>
      </div>
    <?php else: ?>
      <?php 
      $shipments = $tracking_data['data']['shipments'] ?? [];
      if (empty($shipments)): ?>
        <div class="qcx-no-data" style="background: #fff3e0; border: 1px solid #ff9800; padding: 15px; border-radius: 4px; color: #e65100;">
          <p><?php _e('No tracking information found for this shipment.', 'qcx-woocommerce'); ?></p>
        </div>
      <?php else: ?>
        <?php foreach ($shipments as $shipment): ?>
          <div class="qcx-shipment" style="background: #fff; border: 1px solid #e0e0e0; margin-bottom: 20px; border-radius: 8px; overflow: hidden;">
            <div class="qcx-shipment-header" style="background: #1976d2; color: white; padding: 20px;">
              <h2 style="margin: 0; font-size: 24px;"><?php _e('Tracking Number:', 'qcx-woocommerce'); ?> <?php echo esc_html($shipment['shipmentTrackingNumber'] ?? $tracking_id); ?></h2>
              <div style="margin-top: 10px; font-size: 16px;">
                <span class="qcx-status" style="background: rgba(255,255,255,0.2); padding: 5px 10px; border-radius: 15px;">
                  <?php echo esc_html($shipment['status'] ?? 'Unknown'); ?>
                </span>
              </div>
            </div>
            
            <div class="qcx-shipment-details" style="padding: 20px;">
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
                <div class="qcx-sender">
                  <h3 style="color: #1976d2; margin-bottom: 10px;"><?php _e('From', 'qcx-woocommerce'); ?></h3>
                  <div style="background: #f5f5f5; padding: 15px; border-radius: 4px;">
                    <strong><?php echo esc_html($shipment['shipperDetails']['name'] ?? ''); ?></strong><br>
                    <?php $senderAddr = $shipment['shipperDetails']['postalAddress'] ?? []; ?>
                    <?php echo esc_html($senderAddr['cityName'] ?? ''); ?><?php if (!empty($senderAddr['postalCode'])) echo ', ' . esc_html($senderAddr['postalCode']); ?><br>
                    <?php echo esc_html($senderAddr['countryCode'] ?? ''); ?>
                  </div>
                </div>
                
                <div class="qcx-receiver">
                  <h3 style="color: #1976d2; margin-bottom: 10px;"><?php _e('To', 'qcx-woocommerce'); ?></h3>
                  <div style="background: #f5f5f5; padding: 15px; border-radius: 4px;">
                    <strong><?php echo esc_html($shipment['receiverDetails']['name'] ?? ''); ?></strong><br>
                    <?php $receiverAddr = $shipment['receiverDetails']['postalAddress'] ?? []; ?>
                    <?php echo esc_html($receiverAddr['cityName'] ?? ''); ?><?php if (!empty($receiverAddr['postalCode'])) echo ', ' . esc_html($receiverAddr['postalCode']); ?><br>
                    <?php echo esc_html($receiverAddr['countryCode'] ?? ''); ?>
                  </div>
                </div>
              </div>

              <div style="background: #f9f9f9; padding: 15px; border-radius: 4px; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1976d2;"><?php _e('Package Information', 'qcx-woocommerce'); ?></h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
                  <div><strong><?php _e('Weight:', 'qcx-woocommerce'); ?></strong> <?php echo esc_html($shipment['totalWeight'] ?? 'N/A'); ?> kg</div>
                  <div><strong><?php _e('Pieces:', 'qcx-woocommerce'); ?></strong> <?php echo esc_html($shipment['numberOfPieces'] ?? 'N/A'); ?></div>
                  <div><strong><?php _e('Description:', 'qcx-woocommerce'); ?></strong> <?php echo esc_html($shipment['description'] ?? 'N/A'); ?></div>
                </div>
              </div>

              <div class="qcx-events">
                <h3 style="color: #1976d2; margin-bottom: 20px;"><?php _e('Tracking History', 'qcx-woocommerce'); ?></h3>
                <?php if (!empty($shipment['events'])): ?>
                  <div class="qcx-timeline" style="position: relative; padding-left: 30px;">
                    <?php foreach (array_reverse($shipment['events']) as $index => $event): ?>
                      <div class="qcx-event" style="position: relative; padding-bottom: 20px; border-left: 2px solid #e0e0e0;">
                        <div style="position: absolute; left: -8px; top: 5px; width: 14px; height: 14px; border-radius: 50%; background: <?php echo $index === 0 ? '#4caf50' : '#2196f3'; ?>;"></div>
                        <div style="margin-left: 20px; background: white; padding: 15px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                          <div style="font-weight: bold; color: #1976d2; margin-bottom: 5px;">
                            <?php echo esc_html($event['description'] ?? ''); ?>
                          </div>
                          <div style="color: #666; font-size: 14px;">
                            <?php echo esc_html($event['date'] ?? ''); ?> <?php echo esc_html($event['time'] ?? ''); ?>
                          </div>
                          <?php if (!empty($event['serviceArea'][0]['description'])): ?>
                            <div style="color: #888; font-size: 13px; margin-top: 3px;">
                              📍 <?php echo esc_html($event['serviceArea'][0]['description']); ?>
                            </div>
                          <?php endif; ?>
                          <?php if (!empty($event['signedBy'])): ?>
                            <div style="color: #4caf50; font-size: 13px; margin-top: 3px;">
                              ✓ <?php _e('Signed by:', 'qcx-woocommerce'); ?> <?php echo esc_html($event['signedBy']); ?>
                            </div>
                          <?php endif; ?>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>
                <?php else: ?>
                  <p style="color: #666;"><?php _e('No tracking events available yet.', 'qcx-woocommerce'); ?></p>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    <?php endif; ?>
    
    <div style="text-align: center; margin-top: 30px;">
      <a href="<?php echo home_url(); ?>" class="button" style="background: #1976d2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">
        <?php _e('Back to Home', 'qcx-woocommerce'); ?>
      </a>
    </div>
  </div>
  
  <style>
  @media (max-width: 768px) {
    .qcx-tracking-page > div[style*="grid-template-columns"] {
      grid-template-columns: 1fr !important;
    }
  }
  </style>
  <?php
  get_footer();
}
