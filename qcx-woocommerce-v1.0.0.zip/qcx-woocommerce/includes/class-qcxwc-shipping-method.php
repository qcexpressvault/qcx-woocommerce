<?php
/**
 * QC Express Shipping Method for WooCommerce
 */

if (!defined('ABSPATH')) exit;

class QCXWC_Shipping_Method extends WC_Shipping_Method {

  public function __construct($instance_id = 0) {
    $this->id                 = 'qcxwc_shipping';
    $this->instance_id        = absint($instance_id);
    $this->method_title       = __('QC Express', 'qcx-woocommerce');
    $this->method_description = __('QC Express shipping method', 'qcx-woocommerce');
    $this->supports           = ['shipping-zones', 'instance-settings', 'instance-settings-modal'];
    $this->enabled            = 'yes';
    $this->title              = 'QC Express';

    $this->init();
  }

  public function init() {
    $this->init_form_fields();
    $this->init_settings();
    $this->init_instance_settings();

    // Use instance settings for title and enabled status
    $this->title   = $this->get_instance_option('title', 'QC Expressc');
    $this->enabled = $this->get_instance_option('enabled', 'yes');

    add_action('woocommerce_update_options_shipping_' . $this->id, [$this, 'process_admin_options']);
  }

  public function init_form_fields() {
    $this->form_fields = [
      'enabled' => [
        'title'   => __('Enable/Disable', 'qcx-woocommerce'),
        'type'    => 'checkbox',
        'label'   => __('Enable QC Express shipping', 'qcx-woocommerce'),
        'default' => 'yes'
      ],
      'title' => [
        'title'       => __('Title', 'qcx-woocommerce'),
        'type'        => 'text',
        'description' => __('This controls the title which the user sees during checkout.', 'qcx-woocommerce'),
        'default'     => 'QC Express',
        'desc_tip'    => true,
      ],
      'markup_type' => [
        'title'   => __('Markup Type', 'qcx-woocommerce'),
        'type'    => 'select',
        'options' => [
          'none'    => __('No markup', 'qcx-woocommerce'),
          'fixed'   => __('Fixed amount', 'qcx-woocommerce'),
          'percent' => __('Percentage', 'qcx-woocommerce'),
        ],
        'default' => 'none',
      ],
      'markup_value' => [
        'title'       => __('Markup Value', 'qcx-woocommerce'),
        'type'        => 'number',
        'description' => __('Fixed amount (e.g., 100) or percentage (e.g., 15 for 15%)', 'qcx-woocommerce'),
        'default'     => '0',
        'desc_tip'    => true,
        'custom_attributes' => [
          'step' => '0.01',
          'min'  => '0'
        ]
      ],
      'insurance' => [
        'title'       => __('Insurance Options', 'qcx-woocommerce'),
        'type'        => 'select',
        'options'     => [
          'none'     => __('No insurance options', 'qcx-woocommerce'),
          'optional' => __('Let customer choose', 'qcx-woocommerce'),
          'required' => __('Always include insurance', 'qcx-woocommerce'),
        ],
        'description' => __('Control how insurance is handled for this shipping method.', 'qcx-woocommerce'),
        'default'     => 'none',
        'desc_tip'    => true,
      ],
    ];

    $this->instance_form_fields = $this->form_fields;
  }

  public function is_available($package) {
    if ($this->get_instance_option('enabled', 'yes') === 'no') return false;
    
    // Check if QCX settings are configured
    $env = qcxwc_env();
    if (empty($env['base']) || empty($env['client_id']) || empty($env['token'])) {
      return false;
    }

    return true;
  }

  public function calculate_shipping($package = []) {
    $dest = $package['destination'];
    if (empty($dest['country'])) return;

    $opts = qcxwc_opts();

    // 1) Decide document vs non_document
    // Simple rule: if any cart item has shipping class "document", use "document"; else default setting.
    $docType = $opts['default_doc_type'] ?? 'non_document';
    foreach ($package['contents'] as $line) {
      $product = $line['data'];
      if ($product && method_exists($product, 'get_shipping_class') && $product->get_shipping_class() === 'document') {
        $docType = 'document';
        break;
      }
    }

    // 2) Build shipper (origin) and receiver (destination)
    $shipper = [
      'postalCode'   => $opts['origin_postal']  ?? '',
      'cityName'     => $opts['origin_city']    ?? '',
      'addressLine1' => $opts['origin_addr1']   ?? '',
      'addressLine2' => !empty($opts['origin_addr2']) ? $opts['origin_addr2'] : '-',
      'countryCode'  => strtoupper($opts['origin_country'] ?? 'NG'),
    ];

    $receiver = [
      'postalCode'   => $dest['postcode'] ?: '',
      'cityName'     => $dest['city'] ?: '',
      'addressLine1' => $dest['address'] ?? ($dest['address_1'] ?? ''), // depends on how Woo provides it
      'addressLine2' => !empty($dest['address_2']) ? $dest['address_2'] : '-',
      'countryCode'  => strtoupper($dest['country']),
    ];
    // Optional state/county fields if your API accepts them:
    if (!empty($dest['state']))  { $receiver['countyName'] = $dest['state']; }
    if (!empty($opts['origin_state'])) { $shipper['countyName'] = $opts['origin_state']; }

    // 3) Packages: sum weight; use largest dims from items or fallback defaults
    $totalWeight = 0.0;
    $maxL = (int)($opts['default_length'] ?? 10);
    $maxW = (int)($opts['default_width']  ?? 10);
    $maxH = (int)($opts['default_height'] ?? 10);

    foreach ($package['contents'] as $line) {
      $p = $line['data']; $qty = (int)$line['quantity'];
      if (!$p) continue;
      $w = (float)($p->get_weight() ?: 0);
      $l = (float)($p->get_length() ?: 0);
      $wcm= (float)($p->get_width()  ?: 0);
      $h = (float)($p->get_height() ?: 0);

      $totalWeight += max(0, $w) * $qty;
      if ($l > $maxL) $maxL = (int)ceil($l);
      if ($wcm> $maxW) $maxW = (int)ceil($wcm);
      if ($h > $maxH) $maxH = (int)ceil($h);
    }
    // Woo weight may be in g; convert to kg if needed:
    $weight_unit = get_option('woocommerce_weight_unit'); // 'kg' or 'g' etc.
    if ($weight_unit === 'g') $totalWeight = $totalWeight / 1000;
    $totalWeight = max(0.1, round($totalWeight, 3)); // minimum 0.1kg

    $packages = [[
      'weight' => $totalWeight,
      'dimensions' => [
        'length' => $maxL,
        'width'  => $maxW,
        'height' => $maxH,
      ],
    ]];

    // 4) plannedShippingDateAndTime in your required format (WAT / Africa/Lagos)
    $tz   = wp_timezone(); // uses WP -> Settings -> General timezone (set to Africa/Lagos)
    $now  = new DateTime('now', $tz);
    // Format like "2025-03-13T01:32:36 GMT+01:00"
    $offsetMin = (int)$tz->getOffset($now) / 60;
    $sign = $offsetMin >= 0 ? '+' : '-';
    $hh = str_pad((string)floor(abs($offsetMin)/60), 2, '0', STR_PAD_LEFT);
    $mm = str_pad((string)(abs($offsetMin)%60), 2, '0', STR_PAD_LEFT);
    $planned = $now->format('Y-m-d\TH:i:s') . " GMT{$sign}{$hh}:{$mm}";

    // 5) Insurance + declared value
    $currency = get_woocommerce_currency();
    $declared = max(1, (float)WC()->cart->get_displayed_subtotal()); // or order total; adjust if needed
    $insurance_option = $this->get_instance_option('insurance', 'none');

    // 6) Determine delivery type based on destination country
    $deliveryType = (strtoupper($dest['country']) === 'NG') ? 'domestic' : 'export';

    // Determine which insurance options to offer
    $insurance_variants = [];
    if ($insurance_option === 'none') {
      $insurance_variants = [false]; // No insurance
    } elseif ($insurance_option === 'required') {
      $insurance_variants = [true]; // Always insurance
    } else { // 'optional'
      $insurance_variants = [false, true]; // Both options
    }

    $rates_to_add = [];

    foreach ($insurance_variants as $include_insurance) {
      $payload = [
        'document' => $docType,                // 'document' | 'non_document'
        'deliveryType' => $deliveryType,       // 'domestic' for Nigeria, 'export' for international
        'customerDetails' => [
          'shipperDetails'  => $shipper,
          'receiverDetails' => $receiver,
        ],
        'plannedShippingDateAndTime' => $planned,
        'packages' => $packages,
        'insurance' => $include_insurance,
        'monetaryAmount' => [[
          'typeCode' => 'declaredValue',
          'value'    => $declared > 0 ? round($declared, 2) : 1,
          'currency' => $currency ?: 'NGN',
        ]],
      ];

      // Cache quotes briefly while customer tweaks address
      $cache_key = 'qcx_quote_'.md5(wp_json_encode($payload));
      $ttl       = max(0, (int)($opts['cache_minutes'] ?? 3)) * MINUTE_IN_SECONDS;
      $ratesResp = get_transient($cache_key);
      
      // Always log the API payload being sent
      wc_get_logger()->info('QCX API Request Payload', [
        'source' => 'qcxwc',
        'payload' => $payload,
        'delivery_type' => $deliveryType,
        'destination_country' => $dest['country'],
        'insurance_enabled' => $include_insurance,
        'cache_hit' => !empty($ratesResp)
      ]);
      
      if (!$ratesResp) {
        $client = new QCXWC_Client();
        $ratesResp = $client->request('POST', '/api/v1/price/fetch', $payload);
        
        // Always log the API response
        if (is_wp_error($ratesResp)) {
          wc_get_logger()->error('QCX API Error Response', [
            'source' => 'qcxwc',
            'error_message' => $ratesResp->get_error_message(),
            'error_data' => $ratesResp->get_error_data(),
            'insurance' => $include_insurance
          ]);
          continue; // Skip this variant and try the next one
        } else {
          wc_get_logger()->info('QCX API Success Response', [
            'source' => 'qcxwc',
            'response' => $ratesResp,
            'insurance' => $include_insurance
          ]);
        }
        
        if ($ttl) set_transient($cache_key, $ratesResp, $ttl);
      } else {
        wc_get_logger()->info('QCX Using Cached Response', [
          'source' => 'qcxwc',
          'cached_response' => $ratesResp,
          'insurance' => $include_insurance
        ]);
      }

      // Handle the actual API response format with success/data structure
      if (!is_array($ratesResp) || empty($ratesResp['success'])) {
        wc_get_logger()->error('QCX price error: unexpected response', [
          'source'=>'qcxwc',
          'resp'=>$ratesResp,
          'insurance' => $include_insurance
        ]);
        continue; // Skip this variant
      }

      $data       = $ratesResp['data'] ?? [];
      $total      = isset($data['totalPrice']) ? (float)$data['totalPrice'] : 0.0;
      $shipCost   = isset($data['shippingCost']) ? (float)$data['shippingCost'] : $total; // fallback
      $insurance_cost = isset($data['insurance']) ? (float)$data['insurance'] : 0.0;
      $grossW     = isset($data['breakDown']['grossWeight']) ? (float)$data['breakDown']['grossWeight'] : null;

      // Safety: ignore zero/negative totals
      if ($total <= 0 && $shipCost <= 0) {
        wc_get_logger()->warning('QCX price: zero total returned', [
          'source'=>'qcxwc',
          'resp'=>$ratesResp,
          'insurance' => $include_insurance
        ]);
        continue; // Skip this variant
      }

      // prefer totalPrice (what customer pays); fall back to shippingCost
      $baseAmount = $total > 0 ? $total : $shipCost;

      // Apply markup if configured
      $amount = $this->apply_markup($baseAmount);
      
      // Ensure amount is properly formatted as float
      $amount = round((float)$amount, 2);

      // Build a readable label
      $parts = [];
      $base_label = ($docType === 'document') ? __('QCX Document','qcx-woocommerce') : __('QC Express','qcx-woocommerce');
      $parts[] = $base_label;
      
      if ($grossW) $parts[] = sprintf(__('%.2f kg','qcx-woocommerce'), $grossW);
      
      // Add insurance info to label if customer has choice
      if ($insurance_option === 'optional') {
        if ($include_insurance) {
          $parts[] = __('with Insurance', 'qcx-woocommerce');
        } else {
          $parts[] = __('no Insurance', 'qcx-woocommerce');
        }
      }
      
      $label = implode(' • ', $parts);

      // Unique rate id
      $insurance_suffix = $include_insurance ? '_insured' : '_uninsured';
      $rate_id = $this->id . ':' . ($docType === 'document' ? 'doc' : 'parcel') . $insurance_suffix;

      $rates_to_add[] = [
        'id'       => $rate_id,
        'label'    => $label,
        'cost'     => $amount,
        'calc_tax' => 'per_order',
        'meta_data'=> [
          'qcx_doc_type' => $docType,               // 'document' | 'non_document'
          'qcx_currency' => $currency,
          'qcx_raw'      => $ratesResp,             // keep full raw for debugging
          'qcx_breakdown'=> $data['breakDown'] ?? [], // bookingCharge, insurance, etc.
          'qcx_amount'   => $amount,                // Store amount for verification
          'qcx_insurance'=> $include_insurance,     // Track insurance status
        ],
      ];
      
      // Log the rate being prepared
      wc_get_logger()->info('QCX Rate Prepared', [
        'source' => 'qcxwc',
        'rate_id' => $rate_id,
        'label' => $label,
        'cost' => $amount,
        'base_amount' => $baseAmount,
        'type' => gettype($amount),
        'api_total_price' => $total,
        'api_shipping_cost' => $shipCost,
        'insurance_cost' => $insurance_cost,
        'insurance_enabled' => $include_insurance,
        'markup_applied' => $amount != $baseAmount,
        'weight_kg' => $grossW
      ]);
    }

    // Add all prepared rates
    foreach ($rates_to_add as $rate) {
      $this->add_rate($rate);
    }
  }

  /**
   * Apply markup to shipping cost
   */
  private function apply_markup($amount) {
    $markup_type = $this->get_instance_option('markup_type', 'none');
    $markup_value = (float)$this->get_instance_option('markup_value', 0);

    if ($markup_type === 'none' || $markup_value <= 0) {
      return $amount;
    }

    if ($markup_type === 'fixed') {
      return $amount + $markup_value;
    } elseif ($markup_type === 'percent') {
      return $amount * (1 + ($markup_value / 100));
    }

    return $amount;
  }
}
