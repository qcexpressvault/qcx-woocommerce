<?php
if (!defined('ABSPATH')) exit;

class QCXWC_Business {
  const CACHE_KEY = 'qcxwc_business_cache';
  const CACHE_TTL = 10 * MINUTE_IN_SECONDS; // cache for 10 minutes

  /** Fetch fresh from API and store */
  public static function refresh(): array|WP_Error {
    $client = new QCXWC_Client();
    $res = $client->get_business_details();
    if (is_wp_error($res)) return $res;

    // Optionally normalize keys you care about
    // Example expected shape: { "name":"...", "outstanding":12345.67, "currency":"NGN", "account": { "bank":"...", "number":"..." } }
    $payload = [
      'fetched_at'   => time(),
      'data'         => is_array($res) ? $res : [],
    ];
    set_transient(self::CACHE_KEY, $payload, self::CACHE_TTL);
    return $payload;
  }

  /** Get cached (or refresh if missing/expired) */
  public static function get(): array|WP_Error {
    $cache = get_transient(self::CACHE_KEY);
    if ($cache && is_array($cache)) return $cache;
    return self::refresh();
  }

  /** Helper to format currency safely */
  public static function money($amount, $currency = ''): string {
    $amount = is_numeric($amount) ? (float)$amount : 0.0;
    $formatted = number_format($amount, 2, '.', ',');
    return $currency ? "{$currency} {$formatted}" : $formatted;
  }
}
