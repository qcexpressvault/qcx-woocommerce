<?php
/**
 * QC Express API Client Extension
 * Additional methods for the QCXWC_Client class
 */

if (!defined('ABSPATH')) exit;

// Extend the main QCXWC_Client class with additional methods
if (class_exists('QCXWC_Client')) {
  class QCXWC_Client_Extended extends QCXWC_Client {
    
    public function get_business_details() {
      // Use the same endpoint as the business class
      return $this->request('GET', '/api/v1/business/business-info');
    }

    public function fetch_shipping_quote(array $payload) {
      // Shipping quote endpoint - adjust this to match your actual API
      return $this->request('POST', '/api/v1/shipping/quote', $payload);
    }

    public function fetch_price(array $payload) {
      // Legacy method - redirect to shipping quote
      return $this->fetch_shipping_quote($payload);
    }

    public function create_shipment(array $payload) {
      // Create shipment endpoint
      return $this->request('POST', '/api/v1/shipments', $payload);
    }

    public function track_shipment(string $tracking_number) {
      // Track shipment endpoint
      return $this->request('GET', "/api/v1/shipments/track/{$tracking_number}");
    }

    public function cancel_shipment(string $shipment_id) {
      // Cancel shipment endpoint
      return $this->request('DELETE', "/api/v1/shipments/{$shipment_id}");
    }
  }
}